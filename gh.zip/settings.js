const fs = require('fs');
const chalk = require('chalk');
const { version } = require("./package.json")

// Settings Bot 
global.owner = '6282143985744'
global.versi = version
global.namaOwner = "Y u d i s"
global.ownername = "Y u d i s"
global.packname = 'Bot WhatsApp'
global.botname = 'Tenrai - Bot'
global.botname2 = 'Tenrai - Bot'

global.prefa = []
global.autorecordtype = true //auto typing + recording
global.public = false // Default
global.tempatDB = 'database.json' // Jangan ubah
global.pairing_code = true // Jangan ubah

// Settings Link / Tautan
global.linkOwner = "https://wa.me/6282143985744"
global.linkGrup = "https://whatsapp.com/channel/0029Vb1GagK23n3nfwqXVk02"

// Settings Channel / Saluran
global.linkSaluran = "https://whatsapp.com/channel/0029Vb1GagK23n3nfwqXVk02"
global.idSaluran = "120363365201577876@newsletter"
global.namaSaluran = "M u s i c -  R a n d o m"
global.channeljid = "120363365201577876@newsletter"

// Settings Image Url
global.image = {
menu: "https://k.top4top.io/p_3278r0wsm1.jpg", 
reply: "https://k.top4top.io/p_3278r0wsm1.jpg"
}



// Message Command 
global.mess = {
	owner: "* *Akses Ditolak*\nFitur ini hanya untuk owner bot!",
	admin: "* *Akses Ditolak*\nFitur ini hanya untuk admin grup!",
	botAdmin: "* *Akses Ditolak*\nFitur ini hanya untuk ketika bot menjadi admin!",
	group: "* *Akses Ditolak*\nFitur ini hanya untuk dalam grup!",
	private: "* *Akses Ditolak*\nFitur ini hanya untuk dalam private chat!",
	prem: "* *Akses Ditolak*\nFitur ini hanya untuk user premium,  jika ingin premium ketik .owner untuk buy premium!",
	wait: 'Loading...',
	error: 'Error!',
	done: 'Done'
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})